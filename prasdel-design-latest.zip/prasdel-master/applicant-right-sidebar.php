<div class="right-sideabr">
    <h4>Manage Account</h4>
    <ul class="list-item">
        <li><a href="applicant-profile"><img src="http://via.placeholder.com/100"></a></li>
        <li><a href="applicant-profile" class="<?php if($pageTitle == 'My Profile'){echo 'active';}?>">My Profile</a></li>
        <li><a href="applicant-resume" class="<?php if($pageTitle == 'My Resume'){echo 'active';}?>">My Resume / CV</a></li>
        <li><a href="applicant-applications" class="<?php if($pageTitle == 'Applicant Applications'){echo 'active';}?>">My Applications</a></li>
        <li><a href="applicant-application-status" class="<?php if($pageTitle == 'Application Status'){echo 'active';}?>">Application Status <span class="notinumber">2</span></a></li>

        <li><a href="home">Log Out</a></li>
    </ul>
</div>
