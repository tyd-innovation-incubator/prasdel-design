<?php

// redirects to default home page 'home.php'

header('Location: home') ;
?>
