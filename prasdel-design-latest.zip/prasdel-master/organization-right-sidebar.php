<div class="right-sideabr">
    <h4>Manage Account</h4>
    <ul class="list-item">
       <li><a href="organization-company-profile"><img src="http://via.placeholder.com/100"></a></li>
       <li><a href="organization-company-profile" class="<?php if($pageTitle == 'Company Profile'){echo 'active';}?>">Company Profile</a></li>
        <li><a href="organization-post-application" class="<?php if($pageTitle == 'Post Application'){echo 'active';}?>">Post an Application</a></li>
        <li><a href="organization-manage-applications" class="<?php if($pageTitle == 'Manage Applications'){echo 'active';}?>">Manage Applications<span class="notinumber">2</span></a></li>
        <li><a href="organization-applications-list" class="<?php if($pageTitle == 'Organisation Applications List'){echo 'active';}?>">Application List </a></li>

        <li><a href="home">Log Out</a></li>
    </ul>
</div>
