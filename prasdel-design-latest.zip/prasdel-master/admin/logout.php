<?php
header("Location: login");
?>
